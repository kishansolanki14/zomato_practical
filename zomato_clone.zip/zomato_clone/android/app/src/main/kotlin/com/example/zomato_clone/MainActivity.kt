package com.example.zomato_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
