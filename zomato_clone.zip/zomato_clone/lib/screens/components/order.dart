import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:zomato_clone/screens/components/menu.dart';
import 'package:zomato_clone/static_data.dart';

class OrderScreen extends StatelessWidget {
  OrderScreen({super.key});

  final List<String> options = ["Pro", "Rating: 4.0+", "Max Safety", "Fastest Delivery", "Offers", "TakeAway", "Popular"];

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Stack(
            children: [
              Image.asset("asset/zomato_bg.png"),
              Column(
                children: [
                  header(size),
                  searchBar(size),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10.0),
                    child: optionsAvailable(size),
                  ),
                  // offerCard(size),

                  SizedBox(
                    height: size.height / 8,
                  ),
                  itemsList(size),
                  SizedBox(
                    width: size.width / 1.1,
                    child: const Text(
                      "877 restaurants around you",
                      style: TextStyle(
                        fontSize: 25,
                        color: Colors.black,
                        //fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  restaurantsAvailable(size),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget restaurantsAvailable(Size size) {
    return SizedBox(
      height: size.height,
      width: size.width,
      child: ListView.builder(
          physics: const NeverScrollableScrollPhysics(),
          itemCount: restaurantList.length,
          itemBuilder: (context, index) {
            return itemBuilder(size, index, context);
          }),
    );
  }

  Widget itemBuilder(Size size, int index, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 18.0),
      child: GestureDetector(
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MenuScreen())),
        child: Material(
          elevation: 3,
          borderRadius: BorderRadius.circular(18),
          child: SizedBox(
            height: size.height / 2.5,
            width: size.width / 1.1,
            child: Column(
              children: [
                Container(
                  height: size.height / 4,
                  width: size.width / 1.1,
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(18),
                      topRight: Radius.circular(18),
                    ),
                    image: DecorationImage(image: NetworkImage(restaurantList[index].imageUrl ?? ""), fit: BoxFit.cover),
                  ),
                ),
                SizedBox(
                  height: size.height / 12,
                  width: size.width / 1.2,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        restaurantList[index].title ?? "",
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      Container(
                        height: size.height / 25,
                        width: size.width / 7,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.green,
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          restaurantList[index].rating ?? "",
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: size.width / 1.2,
                  child: Text(
                    "${restaurantList[index].locations}   \t\t\t\t\t\t\t\t\t\t\t\t\t\t  ${restaurantList[index].price} for one",
                    style: const TextStyle(
                      fontSize: 12.9,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget itemsList(Size size) {
    return SizedBox(
      height: size.height / 3.25,
      width: size.width,
      child: GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          itemCount: foodItemList.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            mainAxisSpacing: 20,
            childAspectRatio: 0.85,
          ),
          itemBuilder: (context, index) {
            return SizedBox(
              height: size.height / 3,
              width: size.width / 5,
              child: Column(
                children: [
                  Container(
                    height: size.height / 10,
                    width: size.height / 10,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: NetworkImage(
                          foodItemList[index].imageUrl ?? "",
                        ),
                      ),
                    ),
                  ),
                  Text(
                    foodItemList[index].name ?? "",
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  )
                ],
              ),
            );
          }),
    );
  }

  Widget offerCard(Size size) {
    return Container(
      height: size.height / 2.5,
      width: size.width / 1.1,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: const Color.fromRGBO(226, 56, 70, 1),
      ),
      child: Column(
        children: [
          Container(
            height: size.height / 6,
            width: size.height / 6,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              image: DecorationImage(
                image: NetworkImage("https://www.pikpng.com/pngl/m/327-3271979_half-a-pizza-transparent-background-clipart.png"),
              ),
            ),
          ),
          SizedBox(
            width: size.width / 1.25,
            child: const Text(
              "Welcome",
              style: TextStyle(
                color: Colors.white,
                fontSize: 25,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: SizedBox(
              width: size.width / 1.25,
              child: const Text(
                "GET 50% OFF \nON FIRST ORDER",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                ),
              ),
            ),
          ),
          SizedBox(
            width: size.width / 1.25,
            child: const Text(
              "Order Now >",
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget optionsAvailable(Size size) {
    return SizedBox(
      height: size.height / 15,
      width: size.width,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: options.length,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: size.height / 16,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      width: 1,
                      color: Colors.grey,
                    )),
                padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                child: Text(options[index]),
              ),
            );
          }),
    );
  }

  Widget searchBar(Size size) {
    return Container(
      height: size.height / 15,
      width: size.width / 1.12,
      decoration: BoxDecoration(
        border: Border.all(width: 2, color: Colors.grey),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        children: [
          SizedBox(
            width: size.width / 40,
          ),
          const Icon(Icons.search, color: Colors.red),
          SizedBox(
            width: size.width / 20,
          ),
          const Expanded(
            child: TextField(
              decoration: InputDecoration(border: InputBorder.none, hintText: "search"),
            ),
          ),
          IconButton(onPressed: (){}, icon: Icon(Icons.mic)),





        ],
      ),
    );
  }

  Widget header(Size size) {
    return SizedBox(
      height: size.height / 10,
      width: size.width,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsets.all(10.0),
                  child: Icon(
                    Icons.location_on,
                    size: 35,
                    color: Colors.orange,
                  ),
                ),
                Text(
                  "Add Your Location Here",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15)
            ),
              height: 40,
              width: 35,
              child: Image.asset("asset/language.png")),
          SizedBox(width: 10,),
          // IconButton(icon: const Icon(Icons.), onPressed: () {})
          CircleAvatar(
            radius: 20,
            child: ElevatedButton(onPressed: (){}, child: const Text("K"),
            
            ),
          )
          ,
        ],
      ),
    );
  }
}
